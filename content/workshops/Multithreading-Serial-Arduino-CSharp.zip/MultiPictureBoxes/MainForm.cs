﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Workshop
{
    public partial class MainForm : Form
    {
        
        Point[] pt;
        int[] direction;
        int[] speed;

        public MainForm()
        {
            InitializeComponent();
            pt = new Point[3];
            direction = new int[3];
            speed = new int[3];

            pt[0] = GetRandomStart(pictureBox0);
            direction[0] = GetRandomDirection();

            pt[1] = GetRandomStart(pictureBox1);
            direction[1] = GetRandomDirection();

            pt[2] = GetRandomStart(pictureBox2);
            direction[2] = GetRandomDirection();

            speed[0] = trackBar0.Value;
            speed[1] = trackBar1.Value;
            speed[2] = trackBar2.Value;
        }

        public void Draw(Point p, PictureBox pb, float radix)
        {
            try
            {
                Bitmap bmp = new Bitmap(pb.Width, pb.Height);
                Graphics g = Graphics.FromImage(bmp);
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighSpeed;
                g.DrawEllipse(Pens.Black, p.X, p.Y, radix, radix);
                g.FillEllipse(Brushes.Black, p.X, p.Y, radix, radix);
                pb.Image = bmp; 
            }
            catch (Exception) { }
        }

        public void CalculateBounce(int i, PictureBox pb, float radix)
        {

                Draw(pt[i], pb, radix);

                switch (direction[i])
                {
                    case 1:
                        pt[i].X += speed[i];
                        pt[i].Y -= speed[i];
                        break;
                    case 2:
                        pt[i].X -= speed[i];
                        pt[i].Y -= speed[i];
                        break;
                    case 3:
                        pt[i].X -= speed[i];
                        pt[i].Y += speed[i];
                        break;
                    case 4:
                        pt[i].X += speed[i];
                        pt[i].Y += speed[i];
                        break;
                }

                if (pt[i].X <= 0)
                {
                    if (direction[i] == 2)
                        direction[i] = 1;
                    else if (direction[i] == 3)
                        direction[i] = 4;
                }

                else if (pt[i].X >= pb.Width)
                {
                    if (direction[i] == 1)
                        direction[i] = 2;
                    else if (direction[i] == 4)
                        direction[i] = 3;
                }

                else if (pt[i].Y <= 0)
                {
                    if (direction[i] == 1)
                        direction[i] = 4;
                    else if (direction[i] == 2)
                        direction[i] = 3;
                }

                else if (pt[i].Y >= pb.Height)
                {
                    if (direction[i] == 3)
                        direction[i] = 2;
                    else if (direction[i] == 4)
                        direction[i] = 1;
                }
        }

        #region Random Generators

        public Point GetRandomStart(PictureBox pb)
        {
            Random rd = new Random();
            return new Point(rd.Next(pb.Width), rd.Next(pb.Height));
        }

        public int GetRandomDirection()
        {
            Random rd = new Random();
            return rd.Next(3) + 1;
        }

        #endregion  

        #region backgroundWorker[n]

        private void backgroundWorker0_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                CalculateBounce(0, pictureBox0, 5.0f);
                backgroundWorker0.ReportProgress((int)(pt[0].X / 1.25));
                System.Threading.Thread.Sleep(10);
            }
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                CalculateBounce(1, pictureBox1, 12.5f);
                backgroundWorker1.ReportProgress((int)(pt[1].X / 2.5));
                System.Threading.Thread.Sleep(10);
            }
        }

        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                CalculateBounce(2, pictureBox2, 25.0f);
                backgroundWorker2.ReportProgress((int)(pt[2].X / 5));
                System.Threading.Thread.Sleep(10);
            }
        }

        private void backgroundWorker0_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            try { progressBar0.Value = e.ProgressPercentage; }
            catch (Exception) { }
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            try { progressBar1.Value = e.ProgressPercentage; }
            catch (Exception) { }
        }

        private void backgroundWorker2_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            try { progressBar2.Value = e.ProgressPercentage; }
            catch (Exception) { }
        }

        #endregion

        #region Buttons & TrackBars

        private void button0_Click(object sender, EventArgs e)
        {
            backgroundWorker0.RunWorkerAsync();
            button0.Enabled = false; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            backgroundWorker1.RunWorkerAsync();
            button1.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            backgroundWorker2.RunWorkerAsync();
            button2.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button0.PerformClick();
            button1.PerformClick();
            button2.PerformClick();
            button3.Enabled = false;
        }

        private void trackBar0_Scroll(object sender, EventArgs e)
        {
            speed[0] = trackBar0.Value;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            speed[1] = trackBar1.Value;
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            speed[2] = trackBar2.Value;
        }

        #endregion

    }
}
