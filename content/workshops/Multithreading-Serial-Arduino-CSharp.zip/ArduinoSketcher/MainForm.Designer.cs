﻿/*
 * Created by SharpDevelop.
 * User: marcelovca90
 * Date: 26/11/2012
 * Time: 17:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace ArduinoSketcher
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.btnCorPreenchimento = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.backgroundWorkerPosicao = new System.ComponentModel.BackgroundWorker();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.btnCorContorno = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCorDeFundo = new System.Windows.Forms.Button();
            this.checkBoxCoresIguais = new System.Windows.Forms.CheckBox();
            this.btnResetarCores = new System.Windows.Forms.Button();
            this.btnDebugOn = new System.Windows.Forms.Button();
            this.btnDebugOff = new System.Windows.Forms.Button();
            this.textBoxDebug = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusPorta = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusBaudRate = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusTaxaDesenho = new System.Windows.Forms.ToolStripStatusLabel();
            this.backgroundWorkerCores = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCorPreenchimento
            // 
            this.btnCorPreenchimento.BackColor = System.Drawing.Color.Red;
            this.btnCorPreenchimento.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCorPreenchimento.Location = new System.Drawing.Point(630, 38);
            this.btnCorPreenchimento.Name = "btnCorPreenchimento";
            this.btnCorPreenchimento.Size = new System.Drawing.Size(168, 42);
            this.btnCorPreenchimento.TabIndex = 0;
            this.btnCorPreenchimento.Text = " ";
            this.btnCorPreenchimento.UseVisualStyleBackColor = false;
            this.btnCorPreenchimento.Click += new System.EventHandler(this.btnPreenchimentoClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(606, 606);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // backgroundWorkerPosicao
            // 
            this.backgroundWorkerPosicao.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackgroundWorkerPosicaoDoWork);
            // 
            // btnCorContorno
            // 
            this.btnCorContorno.BackColor = System.Drawing.Color.Black;
            this.btnCorContorno.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCorContorno.Location = new System.Drawing.Point(630, 120);
            this.btnCorContorno.Name = "btnCorContorno";
            this.btnCorContorno.Size = new System.Drawing.Size(168, 42);
            this.btnCorContorno.TabIndex = 3;
            this.btnCorContorno.Text = " ";
            this.btnCorContorno.UseVisualStyleBackColor = false;
            this.btnCorContorno.Click += new System.EventHandler(this.btnContornoClick);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(630, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "PREENCHIMENTO";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(630, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(168, 23);
            this.label2.TabIndex = 5;
            this.label2.Text = "CONTORNO";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(630, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 23);
            this.label3.TabIndex = 7;
            this.label3.Text = "COR DE FUNDO";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCorDeFundo
            // 
            this.btnCorDeFundo.BackColor = System.Drawing.Color.White;
            this.btnCorDeFundo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCorDeFundo.Location = new System.Drawing.Point(630, 208);
            this.btnCorDeFundo.Name = "btnCorDeFundo";
            this.btnCorDeFundo.Size = new System.Drawing.Size(168, 42);
            this.btnCorDeFundo.TabIndex = 6;
            this.btnCorDeFundo.Text = " ";
            this.btnCorDeFundo.UseVisualStyleBackColor = false;
            this.btnCorDeFundo.Click += new System.EventHandler(this.BtnCorDeFundoClick);
            // 
            // checkBoxCoresIguais
            // 
            this.checkBoxCoresIguais.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxCoresIguais.Location = new System.Drawing.Point(630, 271);
            this.checkBoxCoresIguais.Name = "checkBoxCoresIguais";
            this.checkBoxCoresIguais.Size = new System.Drawing.Size(168, 42);
            this.checkBoxCoresIguais.TabIndex = 8;
            this.checkBoxCoresIguais.Text = "Preenchimento e Contorno Iguais";
            this.checkBoxCoresIguais.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBoxCoresIguais.UseVisualStyleBackColor = true;
            this.checkBoxCoresIguais.CheckedChanged += new System.EventHandler(this.CheckBoxCoresIguaisCheckedChanged);
            // 
            // btnResetarCores
            // 
            this.btnResetarCores.Location = new System.Drawing.Point(630, 375);
            this.btnResetarCores.Name = "btnResetarCores";
            this.btnResetarCores.Size = new System.Drawing.Size(171, 42);
            this.btnResetarCores.TabIndex = 9;
            this.btnResetarCores.Text = "RESETAR CORES";
            this.btnResetarCores.UseVisualStyleBackColor = true;
            this.btnResetarCores.Click += new System.EventHandler(this.BtnResetarCoresClick);
            // 
            // btnDebugOn
            // 
            this.btnDebugOn.Location = new System.Drawing.Point(630, 327);
            this.btnDebugOn.Name = "btnDebugOn";
            this.btnDebugOn.Size = new System.Drawing.Size(81, 42);
            this.btnDebugOn.TabIndex = 1;
            this.btnDebugOn.Text = "Debug ON";
            this.btnDebugOn.UseVisualStyleBackColor = true;
            this.btnDebugOn.Click += new System.EventHandler(this.BtnDebugOnClick);
            // 
            // btnDebugOff
            // 
            this.btnDebugOff.Enabled = false;
            this.btnDebugOff.Location = new System.Drawing.Point(717, 327);
            this.btnDebugOff.Name = "btnDebugOff";
            this.btnDebugOff.Size = new System.Drawing.Size(81, 42);
            this.btnDebugOff.TabIndex = 10;
            this.btnDebugOff.Text = "Debug OFF";
            this.btnDebugOff.UseVisualStyleBackColor = true;
            this.btnDebugOff.Click += new System.EventHandler(this.BtnDebugOffClick);
            // 
            // textBoxDebug
            // 
            this.textBoxDebug.Location = new System.Drawing.Point(6, 16);
            this.textBoxDebug.Multiline = true;
            this.textBoxDebug.Name = "textBoxDebug";
            this.textBoxDebug.ReadOnly = true;
            this.textBoxDebug.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBoxDebug.Size = new System.Drawing.Size(156, 173);
            this.textBoxDebug.TabIndex = 11;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBoxDebug);
            this.groupBox1.Location = new System.Drawing.Point(630, 423);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(168, 195);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DEBUG";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.statusPorta,
            this.toolStripStatusLabel2,
            this.statusBaudRate,
            this.toolStripStatusLabel3,
            this.statusTaxaDesenho});
            this.statusStrip.Location = new System.Drawing.Point(0, 638);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(818, 22);
            this.statusStrip.SizingGrip = false;
            this.statusStrip.TabIndex = 13;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(72, 17);
            this.toolStripStatusLabel1.Text = "Porta Atual:";
            // 
            // statusPorta
            // 
            this.statusPorta.Name = "statusPorta";
            this.statusPorta.Size = new System.Drawing.Size(25, 17);
            this.statusPorta.Text = "___";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(64, 17);
            this.toolStripStatusLabel2.Text = "BaudRate:";
            // 
            // statusBaudRate
            // 
            this.statusBaudRate.Name = "statusBaudRate";
            this.statusBaudRate.Size = new System.Drawing.Size(25, 17);
            this.statusBaudRate.Text = "___";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(105, 17);
            this.toolStripStatusLabel3.Text = "Taxa de Desenho:";
            // 
            // statusTaxaDesenho
            // 
            this.statusTaxaDesenho.Name = "statusTaxaDesenho";
            this.statusTaxaDesenho.Size = new System.Drawing.Size(25, 17);
            this.statusTaxaDesenho.Text = "___";
            // 
            // backgroundWorkerCores
            // 
            this.backgroundWorkerCores.DoWork += new System.ComponentModel.DoWorkEventHandler(this.BackgroundWorkerCoresDoWork);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 660);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnDebugOff);
            this.Controls.Add(this.btnResetarCores);
            this.Controls.Add(this.checkBoxCoresIguais);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnCorDeFundo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCorContorno);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnDebugOn);
            this.Controls.Add(this.btnCorPreenchimento);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(826, 687);
            this.MinimumSize = new System.Drawing.Size(826, 687);
            this.Name = "MainForm";
            this.Text = "ArduinoSketcher";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		private System.Windows.Forms.ToolStripStatusLabel statusBaudRate;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
		private System.Windows.Forms.ToolStripStatusLabel statusTaxaDesenho;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
		private System.Windows.Forms.ToolStripStatusLabel statusPorta;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
		private System.Windows.Forms.StatusStrip statusStrip;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox textBoxDebug;
		private System.Windows.Forms.Button btnDebugOff;
		private System.Windows.Forms.Button btnResetarCores;
		private System.Windows.Forms.CheckBox checkBoxCoresIguais;
		private System.Windows.Forms.ColorDialog colorDialog;
		private System.Windows.Forms.Button btnCorDeFundo;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCorContorno;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button btnDebugOn;
		private System.Windows.Forms.Button btnCorPreenchimento;
        private System.ComponentModel.BackgroundWorker backgroundWorkerPosicao;
        private System.ComponentModel.BackgroundWorker backgroundWorkerCores;
		
	}
}
