﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace ArduinoSketcher
{
    public partial class FormEscolhePorta : Form
    {
        private String portaSerial;

        public String PortaSerial
        {
            get { return portaSerial; }
            set { portaSerial = value; }
        }

        public FormEscolhePorta()
        {
            InitializeComponent();
            AtualizaPortas();
        }

        public void AtualizaPortas()
        {
            comboBoxPortas.Items.Clear();
            comboBoxPortas.Items.AddRange(SerialPort.GetPortNames());
            if (comboBoxPortas.Items.Count > 0)
            {
                comboBoxPortas.SelectedIndex = 0;
                comboBoxPortas.Invalidate();
            }
        }

        private void btnAtualizaPortas_Click(object sender, EventArgs e)
        {
            AtualizaPortas();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (comboBoxPortas.SelectedIndex != -1)
            {
                this.PortaSerial = comboBoxPortas.SelectedItem.ToString();
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
                MessageBox.Show("Escolha uma porta na lista.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

    }
}
