package br.inatel.ke.structure.facade;

import br.inatel.ke.structure.facade.HelperFacade.InputFileType;
import br.inatel.ke.structure.facade.HelperFacade.OutputFileType;

/**
 * @author marcelovca90 22/09/2015
 */
public class _Main {

	public static void main(String[] args) {

		HelperFacade.generateReport(InputFileType.CSV, OutputFileType.HTML, "data/sample.csv", "data/reports/sample.csv.html");;
		HelperFacade.generateReport(InputFileType.CSV, OutputFileType.TEXT, "data/sample.csv", "data/reports/sample.csv.txt");
		HelperFacade.generateReport(InputFileType.DSV, OutputFileType.HTML, "data/sample.dsv", "data/reports/sample.psv.html");
		HelperFacade.generateReport(InputFileType.DSV, OutputFileType.TEXT, "data/sample.dsv", "data/reports/sample.psv.txt");
	}

}
