package br.inatel.ke.behavior.command;

/**
 * @author marcelovca90 21/09/2015
 */
public class Decrement implements Command {

	private Accumulator acc;
	
	public Decrement(Accumulator acc) {
		this.acc = acc;
	}
	
	@Override
	public void execute() {
		System.out.println(this.getClass().toString() + ": execute()");
		this.acc.setValue(this.acc.getValue()-1);
	}

	@Override
	public void undo() {
		System.out.println(this.getClass().toString() + ": undo()");
		this.acc.setValue(this.acc.getValue()+1);
	}
	
	@Override
	public String toString() {
		return "[--]";
	}

}
