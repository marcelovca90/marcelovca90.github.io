package br.inatel.ke.creation.prototype;

/**
 * @author marcelovca90 22/09/2015
 */
public class _Main {

	public static void main(String[] args) {

		try {
			
			Person person1 = new Person("John Doe", 28, 6.0); 
			System.out.println("person1 = " + person1);
			Person person2 = (Person)person1.clone();
			System.out.println("person2 = " + person2);
			System.out.println("person1 == person2 ? " + (person1 == person2));
			
			System.out.println("----------------------------------------------------------------");
			
			People people1 = new People();
			people1.addPerson(person1);
			people1.addPerson(person2);
			System.out.println("people1 = " + people1);
			People people2 = (People)people1.clone();
			System.out.println("people2 = " + people1);
			System.out.println("people1 == people2 ? " + (people1 == people2));
			
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
	}

}
