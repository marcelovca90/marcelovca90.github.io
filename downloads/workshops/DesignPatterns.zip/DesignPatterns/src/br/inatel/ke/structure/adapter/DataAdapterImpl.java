package br.inatel.ke.structure.adapter;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * @author marcelovca90 23/09/2015
 */
public class DataAdapterImpl implements DataAdapter {

	private static DataReader imageReader = new ImageReader();
	private static DataReader textReader  = new TextReader();
	
	@Override
	public byte[] getBytesFromImage(String filename) {
		byte[] bytes = null;
		try {
			BufferedImage image = (BufferedImage)imageReader.getData(filename);
			String extension = filename.substring(filename.indexOf(".") + 1);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(image, extension, baos);
			bytes = baos.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bytes;
	}

	@Override
	public byte[] getBytesFromText(String filename) {
		byte[] bytes = null;
		try {
			String data = (String)textReader.getData(filename);
			bytes = data.getBytes();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bytes;
	}

}
