package br.inatel.ke.creation.prototype;

import java.util.ArrayList;
import java.util.List;

/**
 * @author marcelovca90 22/09/2015
 */
public class People implements Cloneable {
	
	private List<Person> members;
	
	public People() {
		this.members = new ArrayList<Person>();
	}
	
	public People(List<Person> members) {
		this.members = members;
	}
	
	public void addPerson(Person person) {
		this.members.add(person);
	}

	@Override
	public String toString() {
		return "People [members=" + members + "]";
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		List<Person> temp = new ArrayList<Person>();
		for (Person p : this.members)
			temp.add(p);
		return new People(temp);
	}

}
