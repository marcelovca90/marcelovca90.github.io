package br.inatel.ke.structure.adapter;

import java.io.IOException;

/**
 * @author marcelovca90 23/09/2015
 */
public interface DataReader {

	public Object getData(String filename) throws IOException;
	
}
