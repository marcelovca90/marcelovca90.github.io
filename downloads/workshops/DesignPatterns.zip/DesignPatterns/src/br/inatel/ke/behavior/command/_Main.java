package br.inatel.ke.behavior.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * @author marcelovca90 21/09/2015
 */
public class _Main {

	private static Scanner scanner = new Scanner(System.in);

	private static Accumulator acc = new Accumulator();
	private static List<Command> list = new ArrayList<Command>();
	private static int currentIndex = -1;

	public static void printList() {
		
		if (list.isEmpty())
			System.out.println("Command list is empty.");
		else {
			for (int i=0; i<list.size(); i++) {
				if ((i % 8) == 0) System.out.println();
				if (i == currentIndex) System.out.print("[" + list.get(i) + "] ");
				else System.out.print(" " + list.get(i) + "  ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		
		char opMenu = '!';
		
		while (true) {
			System.out.println("--------------------------------------------");
			System.out.println("Current value = " + acc.getValue());
			System.out.println("--------------------------------------------");
			System.out.println("[I]ncrement [D]ecrement [U]ndo [R]edo [E]xit");
			System.out.println("--------------------------------------------");
			System.out.print("Choose an option: ");
			opMenu = Character.toUpperCase(scanner.next().charAt(0));
			System.out.println("--------------------------------------------");

			switch (opMenu) {

			case 'I':
				list.add(new Increment(acc));
				currentIndex = list.size() - 1;
				list.get(currentIndex).execute();
				break;

			case 'D':
				list.add(new Decrement(acc));
				currentIndex = list.size() - 1;
				list.get(currentIndex).execute();
				break;

			case 'U':
				if (currentIndex > 0) {
					list.get(currentIndex).undo();
					currentIndex--;
				} else {
					System.out.println("Nothing to be undone.");
				}
				break;

			case 'R':
				if (currentIndex < list.size() - 1) {
					list.get(currentIndex).execute();
					currentIndex++;
				} else {
					System.out.println("Nothing do be redone.");
				}
				break;

			case 'E':
				scanner.close();
				System.exit(0);
			}
			
			printList();
		}
	}
	
}
