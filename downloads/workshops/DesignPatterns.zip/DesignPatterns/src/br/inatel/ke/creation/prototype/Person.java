package br.inatel.ke.creation.prototype;

public class Person implements Cloneable {

	private String name;
	private int age;
	private double height;
	
	public Person(String name, int age, double height) {
		this.name = name;
		this.age = age;
		this.height = height;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", height=" + height + "]";
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		return new Person(this.name, this.age, this.height);
	}

}
