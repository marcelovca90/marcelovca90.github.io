package br.inatel.ke.behavior.template;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Calendar;

import org.json.JSONObject;
import org.json.XML;

/**
 * @author marcelovca90 21/09/2015
 */
public class ConvertTask extends Task {

	public enum ConversionType { JSON_TO_XML, XML_TO_JSON } 

	private String filename;
	private ConversionType conversionType;
	private StringBuffer inputBuffer;
	private StringBuffer outputBuffer;

	public ConvertTask(String filename, ConversionType conversionType) {
		this.filename = filename;
		this.conversionType = conversionType;
		this.inputBuffer = new StringBuffer();
		this.outputBuffer = new StringBuffer();
	}

	@Override
	public void input() {
		System.out.print("[I] " + Calendar.getInstance().getTime() + ": ");
		System.out.print("Reading input file ... ");
		try {
			File file = new File(filename);
			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String line;
			while ((line = bufferedReader.readLine()) != null)
				inputBuffer.append(line);
			bufferedReader.close();
			fileReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found.");
		} catch (IOException e) {
			System.out.println("Cannot read file.");
		}
		System.out.println("ok");
	}

	@Override
	public void process() {
		System.out.print("[P] " + Calendar.getInstance().getTime() + ": ");
		System.out.print("Performing conversion ... ");
		JSONObject jsonObject;
		switch (this.conversionType) {
		case JSON_TO_XML:
			jsonObject = new JSONObject(inputBuffer.toString());
			String xmlObject = XML.toString(jsonObject);
			outputBuffer.append(xmlObject);
			break;
		case XML_TO_JSON:
			jsonObject = XML.toJSONObject(inputBuffer.toString());
			outputBuffer.append(jsonObject.toString(4));
			break;
		}
		System.out.println("ok");
	}

	@Override
	public void output() {
		System.out.print("[O] " + Calendar.getInstance().getTime() + ": ");
		switch (this.conversionType) {
		case JSON_TO_XML:
			System.out.println("JSON -> XML");
			System.out.println(outputBuffer.toString());
			break;
		case XML_TO_JSON:
			System.out.println("XML -> JSON");
			System.out.println(outputBuffer.toString());
			break;
		}
	}

	@Override
	public boolean shouldLog() {
		return false;
	}

}
