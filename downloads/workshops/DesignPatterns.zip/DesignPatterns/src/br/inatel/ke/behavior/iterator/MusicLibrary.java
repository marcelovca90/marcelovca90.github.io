package br.inatel.ke.behavior.iterator;

import java.util.HashSet;
import java.util.Iterator;

/**
 * @author marcelovca90 21/09/2015
 */
public class MusicLibrary implements MediaLibrary, MyIterator {

	private HashSet<byte[]> content;
	
	public MusicLibrary() {
		this.content = new HashSet<byte[]>();
	}
	
	public void add(byte[] value) {
		this.content.add(value);
	}
	
	public void remove(byte[] value) {
		this.content.remove(value);
	}
	
	@Override
	public Object getContent() {
		return this.content;
	}
	
	@Override
	public Iterator<byte[]> getIterator() {
		return this.content.iterator();
	}

}
