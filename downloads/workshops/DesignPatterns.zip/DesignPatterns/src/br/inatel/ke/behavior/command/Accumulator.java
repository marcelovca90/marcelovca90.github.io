package br.inatel.ke.behavior.command;

/**
 * @author marcelovca90 21/09/2015
 */
public class Accumulator {

	private int value;

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	public Accumulator() {
		this.value = 0;
	}
	
}
