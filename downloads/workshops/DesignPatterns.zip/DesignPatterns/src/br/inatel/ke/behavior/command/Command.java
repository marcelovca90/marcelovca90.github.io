package br.inatel.ke.behavior.command;

/**
 * @author marcelovca90 21/09/2015
 */
public interface Command {

	public void execute();
	
	public void undo();
	
}
