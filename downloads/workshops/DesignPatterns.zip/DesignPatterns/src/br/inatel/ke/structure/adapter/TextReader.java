package br.inatel.ke.structure.adapter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author marcelovca90 23/09/2015
 */
public class TextReader implements DataReader {

	@Override
	public Object getData(String filename) throws IOException {
		
		File file = new File(filename);
		FileReader fileReader = new FileReader(file);
		BufferedReader bufferedReader = new BufferedReader(fileReader);
		StringBuffer buffer = new StringBuffer();
		String line, text;
		
		while ((line = bufferedReader.readLine()) != null)
			buffer.append(line);
		
		text = buffer.toString();
		bufferedReader.close();
		fileReader.close();
		
		return text;
	}

}
