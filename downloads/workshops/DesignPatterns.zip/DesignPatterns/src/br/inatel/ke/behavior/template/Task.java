package br.inatel.ke.behavior.template;

import java.util.Calendar;

/**
 * @author marcelovca90 21/09/2015
 */
public abstract class Task {
	
	public final void run() {
		this.input();
		this.process();
		this.output();
		if (this.shouldLog())
			this.log();
	}
	
	protected abstract void input();
	
	protected abstract void process();
	
	protected abstract void output();
	
	protected abstract boolean shouldLog();
	
	protected void log() {
		System.out.println("[L] run() finished at " + Calendar.getInstance().getTime());
	}
	
}
