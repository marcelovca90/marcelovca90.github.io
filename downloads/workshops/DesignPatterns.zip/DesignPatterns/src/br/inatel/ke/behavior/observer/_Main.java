package br.inatel.ke.behavior.observer;

import java.util.Scanner;

public class _Main {
	 
    public static void main(String[] args) {
    	
    	Scanner sc = new Scanner(System.in);
    	
        //create subject
        MyTopic topic = new MyTopic();
         
        //create observers
        Observer sub1 = new MyTopicSubscriber("Subscriber 1");
        Observer sub2 = new MyTopicSubscriber("Subscriber 2");
        Observer sub3 = new MyTopicSubscriber("Subscriber 3");
         
        //register observers to the subject
        topic.register(sub1);
        topic.register(sub2);
        topic.register(sub3);
         
        //attach observer to subject
        sub1.setSubject(topic);
        sub2.setSubject(topic);
        sub3.setSubject(topic);
        
    	//check if any update is available
        sub1.update();
        sub2.update();
        sub3.update();
        
        while (true) {
            
            System.out.print("New message: ");
            String msg = sc.nextLine();
            if (msg.isEmpty())
            	System.out.println("No message was posted.");
            else if (msg.toUpperCase().equals("EXIT")) {
            	sc.close();
            	break;
            } else {
            	topic.postMessage(msg);
            }
            System.out.println();
        }
    }
 
}