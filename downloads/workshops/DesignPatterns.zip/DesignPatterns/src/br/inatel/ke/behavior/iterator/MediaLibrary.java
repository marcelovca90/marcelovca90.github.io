package br.inatel.ke.behavior.iterator;

/**
 * @author marcelovca90 22/09/2015
 */
public interface MediaLibrary {

	public Object getContent();
	
}
