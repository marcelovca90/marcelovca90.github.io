package br.inatel.ke.structure.facade;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author marcelovca90 22/09/2015
 */
public class DsvHelper {

	private static StringBuffer readData(String sourceFilename) {
		
		StringBuffer buffer = new StringBuffer();
		try { 
			File file = new File(sourceFilename);
			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String line;
			while ((line = bufferedReader.readLine()) != null)
				buffer.append(line + "\r\n");		
			bufferedReader.close();
			fileReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return buffer;
	}
	
	private static boolean writeData(StringBuffer data, String destinationFilename) {
		
		try {
			File file = new File(destinationFilename);
			if(!file.exists())
				file.createNewFile();
			FileWriter fileWriter = new FileWriter(file);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			bufferedWriter.write(data.toString());
			bufferedWriter.flush();
			bufferedWriter.close();
			fileWriter.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

	public static void generateHtmlReport(String sourceFilename, String destinationfilename) {

		String[] data = readData(sourceFilename).toString().split("\\r?\\n");
		StringBuffer buffer = new StringBuffer();
		
		buffer.append("<html><body><table border=1>");
		for (String line : data) {
			buffer.append("<tr>");
			for (String piece : line.split("-"))
				buffer.append("<td>" + piece + "</td>");
			buffer.append("</tr>");
		}
		buffer.append("</table></body></html>");
		writeData(buffer, destinationfilename);
		System.out.println("[DSV -> HTML] Report written to file '" + destinationfilename + "'");
	}

	public static void generateTextReport(String sourceFilename, String destinationfilename) {

		String[] data = readData(sourceFilename).toString().split("\\r?\\n");
		StringBuffer buffer = new StringBuffer();
		boolean isFirstLine = true;
		for (String line : data) {
			if (isFirstLine) {
				buffer.append("+");
				for (int i=0; i<line.length(); i++)
					buffer.append("-");
				buffer.append("+");
			}
			buffer.append("\r\n|");
			for (String piece : line.split("-"))
				buffer.append(piece + "|");
			buffer.append("\r\n+");
			for (int i=0; i<line.length(); i++)
				buffer.append("-");
			buffer.append("+");
			isFirstLine = false;
		}
		writeData(buffer, destinationfilename);
		System.out.println("[DSV -> TEXT] Report written to file '" + destinationfilename + "'");
	}

}
