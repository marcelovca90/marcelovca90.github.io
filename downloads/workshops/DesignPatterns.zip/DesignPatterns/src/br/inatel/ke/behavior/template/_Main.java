package br.inatel.ke.behavior.template;

import br.inatel.ke.behavior.template.ConvertTask.ConversionType;

/**
 * @author marcelovca90 21/09/2015
 */
public class _Main {
	
	public static void main(String[] args) {
		
		new DownloadTask("https://www.google.com.br/").run();
		System.out.println("----------------------------------------------------------------");
		
		new ConvertTask("data/sample.xml", ConversionType.XML_TO_JSON).run();;
		System.out.println("----------------------------------------------------------------");
		
		new ConvertTask("data/sample.json", ConversionType.JSON_TO_XML).run();;
		System.out.println("----------------------------------------------------------------");
	}

}
