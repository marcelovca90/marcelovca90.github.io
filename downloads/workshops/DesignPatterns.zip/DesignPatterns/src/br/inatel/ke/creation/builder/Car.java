package br.inatel.ke.creation.builder;

/**
 * @author marcelovca90 22/09/2015
 */
public class Car {

	//required parameters
	private String model;
	private int numberOfSeats;
	
    //optional parameters
	private boolean isFuelFlexibe;
	private boolean isTurboCharged;

	public String getModel() {
		return model;
	}
	
	public int getNumberOfSeats() {
		return numberOfSeats;
	}
	
	public boolean isFuelFlexibe() {
		return isFuelFlexibe;
	}
	
	public boolean isTurboCharged() {
		return isTurboCharged;
	}
	
	private Car(CarBuilder builder) {
		this.model = builder.model;
		this.numberOfSeats = builder.numberOfSeats;
		this.isFuelFlexibe = builder.isFuelFlexibe;
		this.isTurboCharged = builder.isTurboCharged;
	}
	
	@Override
	public String toString() {
		return "Car [model=" + model + ", numberOfSeats=" + numberOfSeats
				+ ", isFuelFlexibe=" + isFuelFlexibe + ", isTurboCharged="
				+ isTurboCharged + "]";
	}

	public static class CarBuilder {

		//required parameters
		private String model;
		private int numberOfSeats;
		
	    //optional parameters
		private boolean isFuelFlexibe;
		private boolean isTurboCharged;
		
		public CarBuilder(String model, int numberOfSeats) {
	        this.model = model;
	        this.numberOfSeats = numberOfSeats;
	    }
		
		public CarBuilder setFuelFlexibe(boolean isFuelFlexibe) {
			this.isFuelFlexibe = isFuelFlexibe;
			return this;
		}

		public CarBuilder setTurboCharged(boolean isTurboCharged) {
			this.isTurboCharged = isTurboCharged;
			return this;
		}

	    public Car build() {
	        return new Car(this);
	    }
		
	}
	
}
