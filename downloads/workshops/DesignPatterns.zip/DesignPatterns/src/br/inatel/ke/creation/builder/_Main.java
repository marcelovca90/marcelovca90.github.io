package br.inatel.ke.creation.builder;

/**
 * @author marcelovca90 22/09/2015
 */
public class _Main {

	public static void main(String[] args) {
		
		// Using builder to get the object in a single line of code and
		// without any inconsistent state or arguments management issues

		Car car1 = new Car.CarBuilder("Audi A5 Coup�", 2).setFuelFlexibe(false)
				.setTurboCharged(true).build();
		System.out.println(car1);

		Car car2 = new Car.CarBuilder("BMW 320i ActiveFlex", 5).setFuelFlexibe(true)
				.setTurboCharged(true).build();
		System.out.println(car2);
	}

}
