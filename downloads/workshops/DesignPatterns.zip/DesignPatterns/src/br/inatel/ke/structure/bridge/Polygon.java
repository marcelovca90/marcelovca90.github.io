package br.inatel.ke.structure.bridge;

public abstract class Polygon {

	// Composition - implementor
    protected Color color;
     
    // Constructor with implementor as input argument
    public Polygon(Color c) {
        this.color = c;
    }
    
    public abstract void applyColor();
	
}
