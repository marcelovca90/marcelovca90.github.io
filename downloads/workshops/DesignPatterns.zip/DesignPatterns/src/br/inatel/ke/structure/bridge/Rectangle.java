package br.inatel.ke.structure.bridge;

public class Rectangle extends Polygon {

	public Rectangle(Color c) {
		super(c);
	}
	
	@Override
	public void applyColor() {
		System.out.print("Rectangle filled with color ");
		super.color.applyColor();
	}

}
