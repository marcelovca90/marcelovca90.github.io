package br.inatel.ke.structure.adapter;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * @author marcelovca90 23/09/2015
 */
public class ImageReader implements DataReader {

	@Override
	public Object getData(String filename) throws IOException {
		File file = new File(filename);
		BufferedImage image = ImageIO.read(file);
		return image;
	}

}
