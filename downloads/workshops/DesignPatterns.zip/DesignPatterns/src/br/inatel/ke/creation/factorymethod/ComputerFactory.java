package br.inatel.ke.creation.factorymethod;

public class ComputerFactory {

	public enum ComputerType { DESKTOP, SERVER };

	public static Computer getComputer(ComputerType type, String ram, String hdd, String cpu) {
		switch (type) {
		case DESKTOP:
			System.out.println("Creating new " + Desktop.class);
			return new Desktop(ram, hdd, cpu);
		case SERVER:
			System.out.println("Creating new " + Server.class);
			return new Server(ram, hdd, cpu);
		}
		return null;
	}


}
