package br.inatel.ke.structure.bridge;

/**
 * @author marcelovca90 23/09/2015
 */
public class _Main {

	public static void main(String[] args) {
			
		Polygon rect = new Rectangle(new GreenColor());
		rect.applyColor();
         
        Polygon tri = new Triangle(new OrangeColor());
        tri.applyColor();
	}

}
