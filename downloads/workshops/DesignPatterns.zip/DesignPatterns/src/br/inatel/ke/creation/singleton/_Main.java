package br.inatel.ke.creation.singleton;

/**
 * @author marcelovca90 21/09/2015
 */
public class _Main {

	public static void main(String[] args) {
		
		Singleton s1 = Singleton.getInstance();
		System.out.println("s1.getCreationDate() = " + s1.getCreationDate());
		
		try {
			for (int i=0; i<15; i++) {
				Thread.sleep(200);
				System.out.print(". ");
			}
			System.out.println();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		Singleton s2 = Singleton.getInstance();
		System.out.println("s2.getCreationDate() = " + s2.getCreationDate());
		
		System.out.println("s1 == s2 ? " + (s1 == s2));
	}

}
