package br.inatel.ke.structure.facade;

/**
 * @author marcelovca90 22/09/2015
 */
public class HelperFacade {
	
	protected enum InputFileType { CSV, DSV };
	protected enum OutputFileType { HTML, TEXT };
	
	public static void generateReport(InputFileType inputType, OutputFileType outputType, String sourceFilename, String destinationFilename) {
		
		switch (inputType) {
		case CSV:
			switch (outputType) {
			case HTML:
				CsvHelper.generateHtmlReport(sourceFilename, destinationFilename);;
				break;
			case TEXT:
				CsvHelper.generateTextReport(sourceFilename, destinationFilename);;
				break;
			}
			break;
		case DSV:
			switch (outputType) {
			case HTML:
				DsvHelper.generateHtmlReport(sourceFilename, destinationFilename);;
				break;
			case TEXT:
				DsvHelper.generateTextReport(sourceFilename, destinationFilename);;
				break;
			}
		}
		
	}
}
