package br.inatel.ke.structure.bridge;

public interface Color {

	public void applyColor();
	
}
