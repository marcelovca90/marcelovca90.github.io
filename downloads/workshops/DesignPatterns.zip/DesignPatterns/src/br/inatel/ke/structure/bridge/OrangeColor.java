package br.inatel.ke.structure.bridge;

public class OrangeColor implements Color {

	@Override
	public void applyColor() {
		System.out.println("orange.");
	}

}
