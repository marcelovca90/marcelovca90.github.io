package br.inatel.ke.structure.proxy;

public class _Main {

	public static void main(String[] args) {
		
		final String username = "marcelo"; 
		final String password = "teste123";
		
		CommandExecutor executor = new CommandExecutorProxy(username,password);
        try {
            executor.runCommand("echo Hello World");
            executor.runCommand("dir /P");
        } catch (Exception e) {
            System.out.println("Exception Message::" + e.getMessage());
        }

	}

}
