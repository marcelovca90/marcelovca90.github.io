package br.inatel.ke.behavior.iterator;

import java.util.Iterator;

/**
 * @author marcelovca90 21/09/2015
 */
public interface MyIterator {

	public Iterator<?> getIterator();
	
}
