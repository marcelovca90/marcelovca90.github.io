package br.inatel.ke.behavior.iterator;

import java.util.Iterator;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;

/**
 * @author marcelovca90 21/09/2015
 */
public class _Main {

	public static void main(String[] args) {
		
		TextLibrary libDoc = new TextLibrary();
		for (int i=0; i<RandomUtils.nextInt(4, 8); i++)
			libDoc.add(RandomStringUtils.randomAlphanumeric(32));
		Iterator<String> docIterator = libDoc.getIterator();
		while (docIterator.hasNext())
			System.out.println(docIterator.next());
		
		MusicLibrary libMusic = new MusicLibrary();
		for (int i=0; i<RandomUtils.nextInt(4, 8); i++)
			libMusic.add(RandomUtils.nextBytes(32));
		Iterator<byte[]> musicIterator = libMusic.getIterator();
		while (musicIterator.hasNext()) {
			for (byte b : musicIterator.next())
				System.out.print(String.format("%02X ", b));
			System.out.println();
		}
	}

}
