package br.inatel.ke.structure.adapter;

import org.apache.commons.lang3.StringUtils;

/**
 * @author marcelovca90 23/09/2015
 */
public class _Main {

	public static void main(String[] args) {

		DataAdapter dataAdapter = new DataAdapterImpl();
		
		byte[] bytesFromImage = dataAdapter.getBytesFromImage("data/sample.png");
		System.out.println("Some of the " + bytesFromImage.length + " bytes from the image file:");
		for (int i=1; i<Math.min(16, bytesFromImage.length); i++)
			System.out.print(StringUtils.leftPad(Integer.toHexString(bytesFromImage[i]), 2, '0') + " ");
		System.out.println("...");
		
		System.out.println("----------------------------------------------------------------");
		
		byte[] bytesFromText = dataAdapter.getBytesFromText("data/sample.txt");
		System.out.println("Some of the " + bytesFromText.length + " bytes from the text file:");
		for (int i=1; i<Math.min(16, bytesFromText.length); i++)
			System.out.print(StringUtils.leftPad(Integer.toHexString(bytesFromText[i]), 2, '0') + " ");
		System.out.println("...");
		
	}

}
