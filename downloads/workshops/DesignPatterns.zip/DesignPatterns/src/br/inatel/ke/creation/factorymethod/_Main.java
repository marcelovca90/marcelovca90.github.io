package br.inatel.ke.creation.factorymethod;

import br.inatel.ke.creation.factorymethod.ComputerFactory.ComputerType;

/**
 * @author marcelovca90 22/09/2015
 */
public class _Main {

	public static void main(String[] args) {
		Computer desktop1 = ComputerFactory.getComputer(ComputerType.DESKTOP, "4GB", "500GB", "Intel Core i5-2500K 3.3Ghz");
		System.out.println(desktop1);
		Computer desktop2 = ComputerFactory.getComputer(ComputerType.DESKTOP, "8GB", "1TB", "Intel Core i7-6700K 4GHz");
		System.out.println(desktop2);
		
		System.out.println("----------------------------------------------------------------");

		Computer server1 = ComputerFactory.getComputer(ComputerType.SERVER, "64GB", "10TB", "4 x Intel Xeon E5-4610 2.4GHz");
		System.out.println(server1);
		Computer server2 = ComputerFactory.getComputer(ComputerType.SERVER, "256GB", "100TB", "16 x Intel Xeon E7-8893 v2 3.4GHz");
		System.out.println(server2);
	}

}
