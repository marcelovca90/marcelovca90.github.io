package br.inatel.ke.structure.proxy;


public interface CommandExecutor {

	public void runCommand(String cmd) throws Exception;
	
}
