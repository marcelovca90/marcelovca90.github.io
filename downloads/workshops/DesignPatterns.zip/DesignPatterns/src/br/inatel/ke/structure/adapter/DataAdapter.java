package br.inatel.ke.structure.adapter;

/**
 * @author marcelovca90 23/09/2015
 */
public interface DataAdapter {
	
	public byte[] getBytesFromImage(String filename);
	
	public byte[] getBytesFromText(String filename);

}
