package br.inatel.ke.behavior.iterator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @author marcelovca90 21/09/2015
 */
public class TextLibrary implements MediaLibrary, MyIterator {

	private List<String> content;
	
	public TextLibrary() {
		this.content = new ArrayList<String>();
	}
	
	public void add(String value) {
		this.content.add(value);
	}
	
	public void remove(String value) {
		this.content.remove(value);
	}
	
	@Override
	public Object getContent() {
		return this.content;
	}
	
	@Override
	public Iterator<String> getIterator() {
		return this.content.iterator();
	}

}
