package br.inatel.ke.structure.bridge;

public class Triangle extends Polygon {

	public Triangle(Color c) {
		super(c);
	}
	
	@Override
	public void applyColor() {
		System.out.print("Triangle filled with color ");
		super.color.applyColor();
	}

}
