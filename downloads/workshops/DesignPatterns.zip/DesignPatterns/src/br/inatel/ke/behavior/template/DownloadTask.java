package br.inatel.ke.behavior.template;

import java.io.IOException;
import java.util.Calendar;

import org.jsoup.Jsoup;

/**
 * @author marcelovca90 21/09/2015
 */
public class DownloadTask extends Task {

	private String url;
	private StringBuffer buffer;

	public DownloadTask(String url) {
		this.url = url;
	}
	
	@Override
	public void input() {
		System.out.print("[I] " + Calendar.getInstance().getTime() + ": ");
		buffer = new StringBuffer();
		try {
			System.out.print("Downloading " + url + " ... ");
			this.buffer.append(Jsoup.connect(url).userAgent("Mozilla").get().html());
			System.out.println("ok");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void process() {
		System.out.print("[P] " + Calendar.getInstance().getTime() + ": ");
		int length = this.buffer.toString().split("\\r?\\n").length;
		System.out.println(length + " lines downloaded");
	}

	@Override
	public void output() {
		System.out.print("[O] " + Calendar.getInstance().getTime() + ": ");
		System.out.print("Clearing buffer ... ");
		buffer.delete(0, buffer.length());
		System.out.println("ok");
	}
	
	@Override
	public boolean shouldLog() {
		return true;
	}

}
