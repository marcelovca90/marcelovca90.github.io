package br.inatel.ke.creation.singleton;

import java.util.Calendar;
import java.util.Date;

/**
 * @author marcelovca90 21/09/2015
 */
public final class Singleton {

	private static Date creationDate = Calendar.getInstance().getTime();
	private static Singleton instance = new Singleton();
	
	private Singleton() { }
	
	public Date getCreationDate() {
		return creationDate;
	}
	
	public static Singleton getInstance() {
		return instance;
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}
	
}
