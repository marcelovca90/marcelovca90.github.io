﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Workshop
{
    public partial class MainForm : Form
    {
        static int N = 2;
        static int delay = 10;
        static SingleBall[] balls;

        private object lockObject = new object();

        public class SingleBall
        {
            public int X, Y, direction, speed, radix;
            public Pen pen;
            public Brush brush;

            public SingleBall(int _x, int _y, int _direction, int _speed, int _radix, Color _color)
            {
                this.X = _x;
                this.Y = _y;
                this.direction = _direction;
                this.speed = _speed;
                this.radix = _radix;
                this.pen = new Pen(_color);
                this.brush = new SolidBrush(_color);
            }

            public override string ToString()
            {
                return String.Format("X: {0}\nY: {1}\ndirection: {2}\nspeed: {3}\nradix: {4}\npen: (R:{5} G:{6} B:{7}) \nbrush: {8}",
                                     this.X, this.Y, this.direction, this.speed, this.radix, this.pen.Color.R, this.pen.Color.G, this.pen.Color.B, this.brush.ToString());
            }
        }

        public MainForm() {

            InitializeComponent();
            SetupInitialConditions();

            backgroundWorker1.RunWorkerAsync();
            backgroundWorker2.RunWorkerAsync();
        }

        #region Bounce Logic

        public void SetupInitialConditions() {

            balls = new SingleBall[N];
            Random rd = new Random();

            for (int i = 0; i < N; i++)
            {
                balls[i] = new SingleBall(rd.Next(pictureBox1.Width),  // X inicial
                                          rd.Next(pictureBox1.Height), // Y inicial
                                          rd.Next(3) + 1,  // direction
                                          rd.Next(10) + 5, // speed
                                          rd.Next(20) + 5, // radix
                                          Color.FromArgb(rd.Next(255), rd.Next(255), rd.Next(255))
                                          );
            }
        }

        public void CalculateBounce(int i)
        {
            switch (balls[i].direction)
            {
                case 1:
                    balls[i].X += balls[i].speed;
                    balls[i].Y -= balls[i].speed;
                    break;
                case 2:
                    balls[i].X -= balls[i].speed;
                    balls[i].Y -= balls[i].speed;
                    break;
                case 3:
                    balls[i].X -= balls[i].speed;
                    balls[i].Y += balls[i].speed;
                    break;
                case 4:
                    balls[i].X += balls[i].speed;
                    balls[i].Y += balls[i].speed;
                    break;
            }

            if (balls[i].X <= 0)
            {
                if (balls[i].direction == 2)
                    balls[i].direction = 1;
                else if (balls[i].direction == 3)
                    balls[i].direction = 4;
            }

            else if (balls[i].X >= pictureBox1.Width)
            {
                if (balls[i].direction == 1)
                    balls[i].direction = 2;
                else if (balls[i].direction == 4)
                    balls[i].direction = 3;
            }

            else if (balls[i].Y <= 0)
            {
                if (balls[i].direction == 1)
                    balls[i].direction = 4;
                else if (balls[i].direction == 2)
                    balls[i].direction = 3;
            }

            else if (balls[i].Y >= pictureBox1.Height)
            {
                if (balls[i].direction == 3)
                    balls[i].direction = 2;
                else if (balls[i].direction == 4)
                    balls[i].direction = 1;
            }
        }

        #endregion

        #region Background Workers

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                CalculateBounce(0);

                try 
                {
                    lock (lockObject)
                    {
                        if (pictureBox1.Image == null)
                            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);

                        Graphics g = Graphics.FromImage(pictureBox1.Image);
                        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighSpeed;
                        g.DrawEllipse(balls[0].pen, balls[0].X, balls[0].Y, balls[0].radix, balls[0].radix);
                        g.FillEllipse(balls[0].brush, balls[0].X, balls[0].Y, balls[0].radix, balls[0].radix);
                        pictureBox1.Invalidate();
                        System.Threading.Thread.Sleep(delay);
                    }
                }
                catch (Exception) { }
            }
        }

        private void backgroundWorker2_DoWork(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                CalculateBounce(1);

                try
                {
                    lock (lockObject)
                    {
                        if (pictureBox1.Image == null)
                            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);

                        Graphics g = Graphics.FromImage(pictureBox1.Image);
                        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighSpeed;
                        g.DrawEllipse(balls[1].pen, balls[1].X, balls[1].Y, balls[1].radix, balls[1].radix);
                        g.FillEllipse(balls[1].brush, balls[1].X, balls[1].Y, balls[1].radix, balls[1].radix);
                        pictureBox1.Invalidate();
                        System.Threading.Thread.Sleep(delay);
                    }
                }
                catch (Exception) { }
            }
        }

        #endregion

        #region UI Methods & Events

        public void RandomizeColors()
        {
            Random rd = new Random();
            for (int i = 0; i < N; i++)
            {
                Color c = Color.FromArgb(rd.Next(255), rd.Next(255), rd.Next(255));
                balls[i].pen = new Pen(c);
                balls[i].brush = new SolidBrush(c);
            }
        }

        public void ClearPictureBox()
        {
            try
            {
                lock (lockObject)
                {
                    pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                    Graphics g = Graphics.FromImage(pictureBox1.Image);
                    g.Clear(Color.White);
                }
            }
            catch (Exception) { }
        }

        private void pictureBox1_DoubleClick(object sender, EventArgs e)
        {
            RandomizeColors();
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClearPictureBox();
        }

        private void randomizeColorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RandomizeColors();
        }

        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < N; i++)
                MessageBox.Show(balls[i].ToString(), String.Format("SingleBall[{0}]", i), MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void Form2_SizeChanged(object sender, EventArgs e)
        {
            ClearPictureBox();
        }

        #endregion

    }
}
