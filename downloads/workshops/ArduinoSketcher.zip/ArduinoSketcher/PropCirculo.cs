﻿/*
 * Created by SharpDevelop.
 * User: Marcelo
 * Date: 29/11/2012
 * Time: 22:48
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace ArduinoSketcher
{
	/// <summary>
	/// Description of PropCirculo.
	/// </summary>
	public class PropCirculo
	{
		private int x;
		private int y;
		private int r;
				
		public int X {
			get { return x; }
			set { x = value; }
		}
		
		public int Y {
			get { return y; }
			set { y = value; }
		}
		
		public int R {
			get { return r; }
			set { r = value; }
		}
		
		public PropCirculo()
		{
			
		}
		
	}
}
