﻿/*
 * Created by SharpDevelop.
 * User: marcelovca90
 * Date: 26/11/2012
 * Time: 17:50
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO.Ports;
using System.Timers;
using System.Windows.Forms;

namespace ArduinoSketcher
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		System.IO.Ports.SerialPort serialPort;
		PropCirculo propCirculo;
		Brush brushGlobal;
		Pen penGlobal;
		Color corDeFundo, bkpColor;
		bool debug;
        int chosenOption;
		String debugString, portaEscolhida;
		
		public MainForm()
		{
			InitializeComponent();
			
			//inicializa vars
			debug = false;
			debugString = null;
            portaEscolhida = null;

            //pega porta desejada atraves do FormEscolhePorta
            FormEscolhePorta fep = new FormEscolhePorta();
            if (fep.ShowDialog() == DialogResult.OK)
                portaEscolhida = fep.PortaSerial;

			//inicializa porta serial
            serialPort = new SerialPort();
            try {
                serialPort.BaudRate = 4800;
                serialPort.PortName = portaEscolhida;
                serialPort.Open(); 
            }
            catch (System.IO.IOException)
            {
                MessageBox.Show("Porta inválida selecionada.\nSaindo do programa.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                System.Environment.Exit(0);
            }
            catch (ArgumentException)
            {
                MessageBox.Show("Janela de seleção de porta foi fechada.\nSaindo do programa.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                System.Environment.Exit(0);
            }
			
			//inicializa objetos referentes ao desenho
			brushGlobal = new SolidBrush(Color.Red);
			penGlobal = new Pen(Color.Black, 3.0f);
			corDeFundo = Color.White;
			
			//inicia BackGround worker de comunicaçao serial
			propCirculo = new PropCirculo();
			backgroundWorkerPosicao.RunWorkerAsync(propCirculo);
			
			//inicializa timer para refresh
			System.Timers.Timer t = new System.Timers.Timer();
			t.Elapsed += new ElapsedEventHandler(timer_Tick);
			t.Interval = 25;
			t.Start();
			
			//atualiza status
			statusPorta.Text = serialPort.PortName.ToString();
			statusBaudRate.Text = serialPort.BaudRate.ToString() + " bps";
			statusTaxaDesenho.Text = 1000/t.Interval + "Hz";
		}
		
		//evento que acontece a cada tick do timer
		public void timer_Tick (object sender, ElapsedEventArgs e) {
			drawCircle(propCirculo.X,propCirculo.Y,propCirculo.R);
			if (debug) AtualizaCaixaDebug();
            System.Threading.Thread.Sleep(10);
		}
		
		//método de desenho
		public void drawCircle(int x, int y, int r) {
			if (pictureBox1.Image == null) {
				Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
				Graphics g = Graphics.FromImage(bmp);
				g.Clear(corDeFundo);
				pictureBox1.Image = bmp;
			}
			else {
                try
                {
                    Graphics g = Graphics.FromImage(pictureBox1.Image);
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.DrawEllipse(penGlobal, x, y, r, r);
                    g.FillEllipse(brushGlobal, x, y, r, r);
                    pictureBox1.Invalidate();
                }
                catch (Exception) { }
			}
		}		
		
		#region Eventos de Botões
		
		void btnPreenchimentoClick(object sender, System.EventArgs e)
		{
            chosenOption = 1;
            try { backgroundWorkerCores.RunWorkerAsync(brushGlobal); }
            catch (InvalidOperationException) { } 
		}
		
		void btnContornoClick(object sender, EventArgs e)
		{
            chosenOption = 2;
            try { backgroundWorkerCores.RunWorkerAsync(penGlobal); }
            catch (InvalidOperationException) { } 
		}
		
		void BtnCorDeFundoClick(object sender, EventArgs e)
		{
            chosenOption = 3;
            try { backgroundWorkerCores.RunWorkerAsync(brushGlobal); }
            catch (InvalidOperationException) { } 
		}
		
		void CheckBoxCoresIguaisCheckedChanged(object sender, EventArgs e)
		{
			if (checkBoxCoresIguais.Checked) {
				bkpColor = penGlobal.Color;
				penGlobal.Color = btnCorPreenchimento.BackColor;				
				btnCorContorno.BackColor = btnCorPreenchimento.BackColor;
			}
			else {
				penGlobal.Color = bkpColor;
				btnCorContorno.BackColor = bkpColor;
			}
		}
		
		void BtnDebugOnClick(object sender, System.EventArgs e)
		{
			textBoxDebug.AppendText("\n---------------------------\n");
			textBoxDebug.AppendText("\n--- DEBUG ON ---\n");
			textBoxDebug.AppendText("\n---------------------------\n");
			debug = true;
			btnDebugOn.Enabled = false;
			btnDebugOff.Enabled = true;
		}
		
		void BtnDebugOffClick(object sender, System.EventArgs e)
		{
			debug = false;
			btnDebugOn.Enabled = true;
			btnDebugOff.Enabled = false;
			textBoxDebug.AppendText("\n---------------------------\n");
			textBoxDebug.AppendText("\n-- DEBUG OFF --\n");
			textBoxDebug.AppendText("\n---------------------------\n");
		}
		
		void BtnResetarCoresClick(object sender, EventArgs e)
		{
			checkBoxCoresIguais.Checked = false;
			brushGlobal = new SolidBrush(Color.Red);
			btnCorPreenchimento.BackColor = Color.Red;
			penGlobal.Color = Color.Black;
			btnCorContorno.BackColor = Color.Black;
			corDeFundo = Color.White;
			btnCorDeFundo.BackColor = Color.White;
			pictureBox1.Image = null;
		}
		
		#endregion
		
		#region BackgroundWorkers
		
		void BackgroundWorkerPosicaoDoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
		{
			while (true) {
				int val;
				string s = serialPort.ReadLine();
				if (int.TryParse(s, out val)) {
					if (val < 3000) {
						propCirculo.X = (val-1000)/2;
					}
					else if (val >= 3000 && val < 5000) {
						propCirculo.Y = (val-3000)/2;
					}
					else {
						propCirculo.R = (val-5000)/5;
					}
					if(debug) 
						debugString = String.Format("RECV: [x={0} y={1} r={2}]\n", 
                                                    propCirculo.X, propCirculo.Y, propCirculo.R);
			        System.Threading.Thread.Sleep(1);
				}
			}	
		}

        void BackgroundWorkerCoresDoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            // chosenOption define qual cor deve ser alterada
            switch (chosenOption)
            {
                case 1: // mudanca da cor do preenchimento
                    if (colorDialog.ShowDialog() == DialogResult.OK)
                    {
                        brushGlobal = new SolidBrush(colorDialog.Color);
                        btnCorPreenchimento.BackColor = colorDialog.Color;
                    }
                    break;

                case 2: // mudanca da cor de contorno
                    if (colorDialog.ShowDialog() == DialogResult.OK)
                    {
                        penGlobal.Color = colorDialog.Color;
                        btnCorContorno.BackColor = colorDialog.Color;
                    }
                    break;

                case 3: // mudanca da cor de fundo
                    if (colorDialog.ShowDialog() == DialogResult.OK)
                    {
                        corDeFundo = colorDialog.Color;
                        btnCorDeFundo.BackColor = colorDialog.Color;
                        pictureBox1.Image = null;
                    }
                    break;
            }
        }
		
		#endregion
		
		#region Debug - Delegate e Método
		
		delegate void ReportaLinhaDebugDelegate(string linhaDebug);
		
		private void ReportaLinhaDebug(string LinhaDebug) {
			if (this.textBoxDebug.InvokeRequired)
				this.textBoxDebug.Invoke(new MethodInvoker(delegate() {this.textBoxDebug.AppendText(LinhaDebug);}));
			else
				this.textBoxDebug.AppendText(LinhaDebug);
		}
		
		public void AtualizaCaixaDebug() {
			new ReportaLinhaDebugDelegate(ReportaLinhaDebug).BeginInvoke(debugString,null,null);
		}

		#endregion
		
	}
}
