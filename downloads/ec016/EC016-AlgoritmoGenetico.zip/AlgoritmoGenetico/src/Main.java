import java.util.ArrayList;
import java.util.List;


public class Main {

	static double LIMIAR_MUTACAO = 0.95;

	static class Individuo {

		public int x, y, z;

		public Individuo(int x, int y, int z) {
			this.x = x;
			this.y = y;
			this.z = z;
		}

		@Override
		public String toString() {
			return "Individuo [x=" + x + ", y=" + y + ", z=" + z + "]";
		}
	}

	public static int avaliar(Individuo i) {

		return (int)Math.abs(1 - (2*i.x + Math.pow(i.y, 2) + i.z));
	}

	public static Individuo[] recombinacao(Individuo a, Individuo b) {

		Individuo c = a, d = b;

		double pontoDivisao = Math.random();

		if (pontoDivisao < 0.5) {
			c = new Individuo(b.x, a.y, a.z);
			d = new Individuo(a.x, b.y, b.z);
		} else {
			c = new Individuo(b.x, b.y, a.z);
			d = new Individuo(a.x, a.y, b.z);
		}

		return new Individuo[] { c, d };
	}

	public static Individuo mutacao(Individuo i) {

		Individuo c = i;

		double pontoMutacao = Math.random();
		double signalMutacao = Math.random() < 0.5 ? -1.0 : +1.0;
		double porctgMutacao = Math.random() < 0.5 ? +0.9 : +1.1;
		double offsetMutacao = Math.random() < 0.5 ? -1.0 : +1.0;

		if (pontoMutacao < 0.3) 
			c.x = (int)(c.x * signalMutacao * porctgMutacao + offsetMutacao);
		else if (pontoMutacao < 0.6) 
			c.y = (int)(c.y * signalMutacao * porctgMutacao + offsetMutacao);
		else 
			c.z = (int)(c.z * signalMutacao * porctgMutacao + offsetMutacao);

		return c;
	}

	public static Individuo gerarIndividuo() {

		double sinalX = Math.random() < 0.5 ? -1 : +1;
		int valorX = (int)(100 * Math.random() * sinalX);

		double sinalY = Math.random() < 0.5 ? -1 : +1;
		int valorY = (int)(100 * Math.random() * sinalY);

		double sinalZ = Math.random() < 0.5 ? -1 : +1;
		int valorZ = (int)(100 * Math.random() * sinalZ);

		return new Individuo(valorX, valorY, valorZ);
	}

	public static List<Individuo> gerarPopulacao(int n) {

		List<Individuo> pop = new ArrayList<Individuo>();

		for (int i=0; i<n; i++)
			pop.add(gerarIndividuo());

		return pop;
	}

	public static void main(String[] args) throws Exception {

		// Inicializar a população de indivíduos;
		List<Individuo> pop = gerarPopulacao(4);

		// contador de epocas
		int epoca = 1;
		boolean encontrouSolucao = false;
		double probMutacao;

		do {
			// Avaliar cada indivíduo na população;
			int melhorFitness, melhorIndice;
			Individuo pai, mae;

			// Selecionar os pais para gerar novos indivíduos;
			melhorFitness = Integer.MAX_VALUE;
			melhorIndice = -1;
			for (int i=0; i<pop.size(); i++) {
				if (avaliar(pop.get(i)) < melhorFitness) {
					melhorFitness = avaliar(pop.get(i));
					melhorIndice = i;
				}
			}
			// Selecionar o pai para gerar novos indivíduos;
			pai = pop.get(melhorIndice);
			// Apagar os velhos indivíduos da população;
			pop.remove(melhorIndice);
			
			// Selecionar os pais para gerar novos indivíduos;
			melhorFitness = Integer.MAX_VALUE;
			melhorIndice = -1;
			for (int i=0; i<pop.size(); i++) {
				if (avaliar(pop.get(i)) < melhorFitness) {
					melhorFitness = avaliar(pop.get(i));
					melhorIndice = i;
				}
			}
			// Selecionar o pai para gerar novos indivíduos;
			mae = pop.get(melhorIndice);
			// Apagar os velhos indivíduos da população;
			pop.remove(melhorIndice);

			// Aplicar os operadores de recombinação e mutação a estes
			// pais de forma a gerar os indivíduos da nova geração;
			probMutacao = Math.random();
			if (probMutacao > LIMIAR_MUTACAO) {
				System.out.println("Pai sofreu mutacao!");
				pai = mutacao(pai);
			}
			probMutacao = Math.random();
			if (probMutacao > LIMIAR_MUTACAO) {
				System.out.println("Mae sofreu mutacao!");
				mae = mutacao(mae);
			}
			Individuo[] filhos = recombinacao(pai, mae);
			
			// Avaliar todos os novos indivíduos e inseri-los na população;
			for (Individuo filho : filhos) {
				probMutacao = Math.random();
				if (probMutacao > LIMIAR_MUTACAO) {
					System.out.println("Filho sofreu mutacao!");
					pop.add(mutacao(filho));
				}
				else {
					pop.add(filho);
				}
			}

			// imprimindo populacao
			System.out.println("\n[Epoca " + (epoca++) + "]");
			for (Individuo i : pop) {
				int fitness = avaliar(i);
				System.out.print(i + " -> fitness = " + fitness);
				if (fitness == 0) {
					System.out.print(" *** ");
					encontrouSolucao = true;
				}
				System.out.println();
			}
			
		} while (!encontrouSolucao);

	}

}
